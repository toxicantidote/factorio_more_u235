--[[
	Part of the 'More uranium-235' mod.
	
	See LICENSE.txt in the root mod folder for licensing details.
--]]
require("prototypes.recipe")
